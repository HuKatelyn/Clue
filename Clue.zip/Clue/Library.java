import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class Library extends Room{

    public Library(int x, int y, Color color,int xString,int yString){
        super(x, y, color, xString, yString);
        setWidth(4);
        setHeight(3);
        setName("Library");
    } 

    

    
}    
