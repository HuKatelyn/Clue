import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
public class Ballroom extends Room{

    public Ballroom(int x, int y, Color color,int xString,int yString){
        super(x, y, color, xString, yString);
        setWidth(5);
        setHeight(6);
        setName("Ballroom");
    }
   


}    
