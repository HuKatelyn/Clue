import java.util.ArrayList; 
import java.awt.Graphics;
import java.awt.Color;

public class Player {
    private String name; 
    private ArrayList<String> cards; 
   

    public Player (String nm, ArrayList<String> crds){
        name = nm; 
        crds = cards; 
    }
    public void drawMe(Graphics g,Color clr,int xcoor, int ycoor){
        g.setColor(clr);
        g.fillOval(xcoor,ycoor,40,40); 
    }

    

   
}