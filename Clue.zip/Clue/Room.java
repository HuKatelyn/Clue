import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class Room{
    
    private int startX;
    private int startY; 
    private int width; 
    private int height;
    private Color color; 
    private String name;
    private int xString;
    private int yString;
    public Room (int startX1, int startY1, Color color1,int xString1,int yString1){
        startX = startX1; 
        startY = startY1; 
        color = color1; 
        xString = xString1;
        yString = yString1;
    }
    

    public int setWidth(int width1){
        width = width1 * 50 ; 
        return width;
    } 
    public int setHeight(int height1){
        height = height1 * 50; 
        return height;
    } 
    public void setName(String roomName){
        name = roomName;
    }

    public void drawMe(Graphics g){
        g.setColor(color);
        g.fillRect(startX,startY,width,height); 
        g.setColor(Color.BLACK);
        Font font = new Font("Serif", Font.PLAIN, 30);
		g.setFont(font);
        g.drawString(name, xString, yString);
    }
}