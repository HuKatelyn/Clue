public class Square{
    public Square(){
        
    }
}