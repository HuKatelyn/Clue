import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class Billiard extends Room{

    public Billiard(int x, int y, Color color,int xString,int yString){
        super(x, y, color, xString, yString);
        setWidth(4);
        setHeight(4);
        setName("Billiard Room");
    } 

    

    
}    
