import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;


import java.net.URL;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
public class Screen extends JPanel implements ActionListener, MouseListener, KeyListener{


//classes
   private String[][] grid;
   private ArrayList<String> cards;


   private Player scarlet;
   private Player mustard;
   private Player plum;
   private Player peacock;


   private ArrayList<String> secretCards ;


   private ArrayList<String> scarletCards;
   private ArrayList<String> mustardCards;
   private ArrayList<String> plumCards;
   private ArrayList<String> peacockCards;


   private boolean[][] doorArray;


   private Billiard billiard;
   private Library library;
   private Study study;
   private Hall hall;
   private Conservatory conservatory;
   private Dining dining;
   private Kitchen kitchen;
   private Lounge lounge;
   private Ballroom ballroom;
  
//colors


   private Font serif;
   private Color blue = new Color(69, 97, 168);
   private Color yellow = new Color(229, 216, 104);
   private Color red = new Color(143, 1, 1);
   private Color mustardYellow = new Color(242, 143, 12);
   private Color darkBlue = new Color(0, 71, 143);
   private Color plumColor = new Color(101, 6, 145);
   private Color brown = new Color (168, 129, 74);
   private Color lightGreen = new Color (143,175,119);
   private Color pink = new Color (175,119,148);
   private Color lightRed = new Color (221,107,102);
   private Color orange = new Color (236,177,47);
   private Color purple = new Color (162,102,221);
   private Color maroon = new Color(101,43,56);
   private Color darkGreen = new Color (48,95,64);
   private Color darkBrown = new Color (108,76,38);
      
//buttons
   private JButton playButton;
   private JButton rulesButton;
   private JButton rollButton;
   private JButton exit;
   private JButton suspectButton;
   private JButton enterRoomButton;
   private JButton nextTurn;
   private JButton accuseButton;
    private JButton playAgain;
   
   private JButton showCards;
   private JButton hideCards; 
   
  
//imgaes
   private BufferedImage board;
   private BufferedImage suspectImg;
  
//int
   private int turn = 1;
   private int squaresToMove = 1; 


   private int scarletX;
   private int scarletY;
   private int peacockX;
   private int peacockY;
   private int mustardX;
   private int mustardY;
   private int plumX;
   private int plumY;

   private int rolled;

   private int correctness = 0;

   private int imgX;


//booleans
   private boolean gameStart = false;
   private boolean showRoll = false; 
   private boolean rules = false;
   private boolean inRoom = false;
   private boolean showSuspection = false;
   private boolean animate;
   private boolean showAccusation = false; 
   private boolean revealCards = false; 
   private boolean won = false;  
   private boolean gameOver = false; 
   private boolean restarting = false; 


//Strings
   private String suspectedRoom = "";
   private String suspectedWeapon = "";
   private String suspectedPerson = "";
   private String text = "";
   private JComboBox<String> roomList;
   private JComboBox<String> weaponList;
   private JComboBox<String> characterList;
   private String showMe = "";
   private String who = "";
   private String soundName;
   private String door = "";
   private String soundName2;




   public Screen(){
       imgX = -575;
       rolled = 0;


       addMouseListener(this);
       addKeyListener(this);
              
       setLayout(null); 
       setFocusable(true);
       setVisible(true);
      
//board
       grid = new String[18][22];
       for(int r = 0 ; r<grid.length; r++){
           for(int c = 0; c<grid[r].length; c++){
               grid[r][c] = new String();
           }
       }


       billiard = new Billiard(0,450,blue,17,516);
       library = new Library (0,250,brown,17,301);
       study = new Study (0,0,lightGreen,29,41);
       hall = new Hall (400,0,pink,473,90);
       conservatory = new Conservatory(0,700,lightRed,17,775);
       dining = new Dining(700,300,orange,763,397);
       kitchen = new Kitchen(750,700,purple,790,772);
       lounge = new Lounge (750,0,maroon,798,67);
       ballroom = new Ballroom(350,600,darkGreen,398,717);
      
       try {
           Scanner scan = new Scanner(new FileReader("Clue_Locations.txt"));
           int r = 0 ;
           //reads one word at a time
           while (scan.hasNextLine()){
               String line = scan.nextLine();
               //System.out.println(line);
               for(int c = 0 ; c<line.length();c++){
                   char ch = line.charAt(c);
                   grid[r][c]= ch + "";
               }
               r++;
           }
       }
       catch (FileNotFoundException e) {
           e.printStackTrace();
       }  






//cards
      


       scarletCards = new ArrayList<String>();
       mustardCards = new ArrayList<String>();
       plumCards = new ArrayList<String>();
       peacockCards = new ArrayList<String>();
       secretCards = new ArrayList<String>();
       cards = new ArrayList<String>();


       cards.add("Person: Colonel Mustard");
       cards.add("Person: Mrs. Scarlet");
       cards.add("Person: Professor Plum");
       cards.add("Person: Mrs. Peacock");
       cards.add("Weapon: Wrench");
       cards.add("Weapon: Rope");
       cards.add("Weapon: Dagger");
       cards.add("Weapon: Candlestick");
       cards.add("Weapon: Revolver");
       cards.add("Weapon: Lead pipe");
       cards.add("Room: Ballroom");
       cards.add("Room: Conservatory");
       cards.add("Room: BillardRoom");
       cards.add("Room: Library");
       cards.add("Room: Study");
       cards.add("Room: Hall");
       cards.add("Room: Lounge");
       cards.add("Room: Dining Room");
       cards.add("Room: Kitchen");
                      
       shuffleCards();
      
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Room")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Person")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Weapon")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       
       scarletCards.add(cards.get(0));
       scarletCards.add(cards.get(1));
       scarletCards.add(cards.get(2));
       scarletCards.add(cards.get(3));


       mustardCards.add(cards.get(4));
       mustardCards.add(cards.get(5));
       mustardCards.add(cards.get(6));
       mustardCards.add(cards.get(7));


       peacockCards.add(cards.get(8));
       peacockCards.add(cards.get(9));
       peacockCards.add(cards.get(10));
       peacockCards.add(cards.get(11));


       plumCards.add(cards.get(12));
       plumCards.add(cards.get(13));
       plumCards.add(cards.get(14));
       plumCards.add(cards.get(15));


       for(int i =0; i<cards.size();i++){
           cards.remove(i);
           i--;
       }
      
//buttons
       playButton = new JButton("Play");
       playButton.setBounds(725, 500, 70, 70); //sets the location and size
       playButton.addActionListener(this); //add the listaener
       this.add(playButton); //add to JPanel


       rollButton = new JButton("Roll");
       rollButton.setBounds(1010, 200, 100, 50); //sets the location and size
       rollButton.addActionListener(this); //add the listaener
       this.add(rollButton); //add to JPanel
       rollButton.setVisible(false);


       rulesButton = new JButton("Rules");
       rulesButton.setBounds(1200, 840, 100, 50); //sets the location and size
       rulesButton.addActionListener(this); //add the listaener
       this.add(rulesButton); //add to JPanel


       //x button
       exit = new JButton("X");
       exit.setBounds(895,295, 15, 15); //sets the location and size
       exit.addActionListener(this); //add the listener
       this.add(exit); //add to JPanel
       exit.setVisible(false);


       suspectButton = new JButton("Suspect");
       suspectButton.setBounds(1100, 525, 100, 50); //sets the location and size
       suspectButton.addActionListener(this); //add the listaener
       this.add(suspectButton); //add to JPanel
       suspectButton.setVisible(false);


       enterRoomButton = new JButton("Enter Room");
       enterRoomButton.setBounds(1150, 200, 100, 50); //sets the location and size
       enterRoomButton.addActionListener(this); //add the listaener
       this.add(enterRoomButton); //add to JPanel
       enterRoomButton.setVisible(false);


       nextTurn = new JButton("Next Turn");
       nextTurn.setBounds(1100, 300, 100, 50); //sets the location and size
       nextTurn.addActionListener(this); //add the listaener
       this.add(nextTurn); //add to JPanel
       nextTurn.setVisible(false);

	   

	   accuseButton = new JButton("Accuse");
       accuseButton.setBounds(1100, 625, 100, 50); //sets the location and size
       accuseButton.addActionListener(this); //add the listaener
       this.add(accuseButton); //add to JPanel
       accuseButton.setVisible(false);
       
       showCards = new JButton("Show Cards");
       showCards.setBounds(1010, 760, 80, 20); //sets the location and size
       showCards.addActionListener(this); //add the listaener
       this.add(showCards); //add to JPanel
       showCards.setVisible(false);

       hideCards = new JButton("Hide Cards");
       hideCards.setBounds(1010, 760, 80, 20); //sets the location and size
       hideCards.addActionListener(this); //add the listaener
       this.add(hideCards); //add to JPanel
       hideCards.setVisible(false);

       playAgain = new JButton("Play Again");
       playAgain.setBounds(1200, 790, 100, 50); //sets the location and size
       playAgain.addActionListener(this); //add the listaener
       this.add(playAgain); //add to JPanel
       playAgain.setVisible(false);






//room dropdown menu
       String[] rooms = { "Study", "Hall", "Lounge", "Dining Room", "Kitchen", "Ballroom", "Conservatory", "Billiard", "Library" };
       roomList = new JComboBox<String>(rooms);
       roomList.setBounds(1000,425, 150,50);
       this.add(roomList);
       roomList.setVisible(false);


       //weapon dropdown menu
       String[] weapons = { "Wrench", "Rope", "Dagger", "Candlestick", "Revolver", "Lead pipe"};
       weaponList = new JComboBox<String>(weapons);
       weaponList.setBounds(1150,425, 150,50);
       this.add(weaponList);
       weaponList.setVisible(false);
      
       //character dropdown menu
       String[] characters = { "Scarlet", "Mustard", "Plum", "Peacock" };
       characterList = new JComboBox<String>(characters);
       characterList.setBounds(1075,475, 150,50);
       this.add(characterList);
       characterList.setVisible(false);
      
//players


       scarletX = 306;
       scarletY = 853;
       peacockX = 954;
       peacockY = 256;
       mustardX = 605;
       mustardY = 857;
       plumX = 956;
       plumY = 607;
      
       scarlet = new Player ("Ms. Scarlet", scarletCards);
       mustard = new Player ("Colonel Mustard",mustardCards);
       plum = new Player ("Professor Plum",plumCards);
       peacock = new Player ("Mrs. Peacock",peacockCards);




//colors and fonts
       serif= new Font("Serif", Font.PLAIN, 50);


       try {
           suspectImg = ImageIO.read(new File("suspect.png"));
       } catch (IOException e) {
           e.printStackTrace();
       }


   }


  


   public Dimension getPreferredSize(){
       return new Dimension(1300,1080);
   }
//pc
  
   public void paintComponent(Graphics g){
      super.paintComponent(g); 

//game starting
       if(gameStart == true){
           rollButton.setVisible(true);
           nextTurn.setVisible(true);
           showCards.setVisible(true); 
            hideCards.setVisible(false); 
            playAgain.setVisible(true); 

           g.setColor(yellow);
           g.fillRect(0,0,1000,900);
           //draw grid
           g.setColor(Color.BLACK);
           int x = 0;
           int y = 0;
           for(int r = 0; r < grid.length; r++){
               for(int c = 0; c < grid[r].length -2; c++){
                    g.drawRect(x,y,50,50);
                  
                   x += 50;
                  
               }
              
               x = 0;
               g.drawRect(x,y,50,50);
               y += 50;   


               Font biggerSerif = new Font("Serif", Font.PLAIN, 100);
               g.setFont(biggerSerif);
               g.drawString("Clue",1050,100);
              


               Font smallerSerif = new Font("Serif", Font.PLAIN, 18);
               g.setFont(smallerSerif);
               if(showRoll == true){
                   if(turn ==1 || turn ==0){
                       g.drawString("Ms. Scarlet's Turn " ,1020,150);
                       g.drawString("Roll: " + squaresToMove,1020,180);
                   }else if(turn==2){
                       g.drawString("Colonel Mustard's Turn " ,1020,150);
                       g.drawString("Roll: " + squaresToMove,1020,180);
                   }else if(turn ==3){
                       g.drawString("Professor Plum's Turn " ,1020,150);
                       g.drawString("Roll: " + squaresToMove,1020,180);
                   }else if(turn ==4){
                       g.drawString("Mrs. Peacock's Turn ",1020,150);
                       g.drawString("Roll: " + squaresToMove,1020,180);
                   }  
               }  
           }


           if(inRoom == true){
               suspectButton.setVisible(true);
               roomList.setVisible(true);
               weaponList.setVisible(true);
               characterList.setVisible(true);
              
              Font smallSerif = new Font("Serif", Font.PLAIN, 15);
              g.setFont(smallSerif);
               g.drawString("Select the cards that you want to suspect, then", 1010, 370);
               g.drawString("press the 'Suspect' button. Hide the screen", 1010, 385);
               g.drawString("from other players", 1010, 400);
               g.drawString("Rooms", 1050, 430);
               g.drawString("Weapons", 1200, 430);
               g.drawString("Characters", 1100, 480);
           } 
          




          
           //rooms
           billiard.drawMe(g);
           study.drawMe(g);
           ballroom.drawMe(g);
           conservatory.drawMe(g);
           dining.drawMe(g);
           hall.drawMe(g);
           kitchen.drawMe(g);
           library.drawMe(g);
           lounge.drawMe(g);


           //tokens
           scarlet.drawMe(g,red,scarletX,scarletY);
           mustard.drawMe(g,mustardYellow,mustardX,mustardY);
           plum.drawMe(g,plumColor,plumX,plumY);
           peacock.drawMe(g,darkBlue, peacockX, peacockY);


           //doors
           //horizontal
           g.setColor(darkBrown);
           g.fillRect(100,150,50,10);
           g.fillRect(50,240,50,10);
           g.fillRect(100,400,50,10);
           g.fillRect(50,440,50,10);
           g.fillRect(100,650,50,10);
      
           g.fillRect(850,690,50,10);
           g.fillRect(850,200,50,10);
           g.fillRect(500,250,50,10);
          
           //vertical
           g.fillRect(250,800,10,50);
           g.fillRect(600,700,10,50);
           g.fillRect(740,750,10,50);
           g.fillRect(740,750,10,50);
           g.fillRect(690,400,10,50);
           g.fillRect(690,450,10,50);
           g.fillRect(740,50,10,50);
           g.fillRect(390,100,10,50);
           g.fillRect(340,700,10,50);


       }else{
           g.setColor(blue);
           g.fillRect(0, 0, 1920, 1080);
           g.setColor(Color.BLACK);
           Font biggerSerif = new Font("Serif", Font.PLAIN, 300);
           g.setFont(biggerSerif);
           g.drawString("Clue", 450, 350);


           //rules screen pops up
           if(rules == true){
               rulesScreen(g);
           }


           //x button
           if(rules == true){
               exit.setVisible(true);
           } else if(rules == false){
               exit.setVisible(false);
           }
       }
      
//turns function
      
       if(turn == 5){
           turn = 1;
       }
//rolls function
      
       //rules screen pops up
       if(rules == true){
           rulesScreen(g);
       }


//x button
       if(rules == true){
           exit.setVisible(true);
      
       } else if(rules == false){
           exit.setVisible(false);
       }
       
       if(turn ==1){
           int tempX = scarletX/50;
           int tempY = scarletY/50;
           if(grid[tempY][tempX].equals("A") || grid[tempY][tempX].equals("B") || grid[tempY][tempX].equals("C") || grid[tempY][tempX].equals("D")){
               enterRoomButton.setVisible(true);
           } else {
                enterRoomButton.setVisible(false);
           }
       } else if(turn == 2){
           int tempX = mustardX/50;
           int tempY = mustardY/50;
           if(grid[tempY][tempX].equals("A") || grid[tempY][tempX].equals("B") || grid[tempY][tempX].equals("C") || grid[tempY][tempX].equals("D")){
               enterRoomButton.setVisible(true);
           } else {
                enterRoomButton.setVisible(false);
           }
       } else if(turn == 3){
           int tempX = plumX/50;
           int tempY = plumY/50;
           if(grid[tempY][tempX].equals("A") || grid[tempY][tempX].equals("B") || grid[tempY][tempX].equals("C") || grid[tempY][tempX].equals("D")){
               enterRoomButton.setVisible(true);
           } else {
                enterRoomButton.setVisible(false);
           }
       } else if(turn == 4){
           int tempX = peacockX/50;
           int tempY = peacockY/50;
           if(grid[tempY][tempX].equals("A") || grid[tempY][tempX].equals("B") || grid[tempY][tempX].equals("C") || grid[tempY][tempX].equals("D")){
               enterRoomButton.setVisible(true);
           } else {
                enterRoomButton.setVisible(false);
           }
       }
//suspect display
       if(showSuspection==true){
           //System.out.println(showMe);
           g.setColor(Color.BLACK);
           Font smallSerif = new Font("Serif", Font.PLAIN, 15);
           g.setFont(smallSerif);
           g.drawString(showMe + " was in " + who + "'s cards", 1010,600 );
           g.drawImage(suspectImg, imgX, 300, null);
		   g.drawString("If you would like to accuse, it will use the",1010,700);
		   g.drawString("fields you select in the drop down menu",1010,715);
           g.drawString("above",1010,730);
       }
//accuse display 
		if(showAccusation==true){
			g.setColor(Color.BLACK);
            Font smallSerif = new Font("Serif", Font.PLAIN, 15);
            g.setFont(smallSerif);
			if(correctness==3){
				g.drawString("You accusation is correct! You have won. ",1010,750);
                won = true; 
                gameOver = true;
			}else{
				g.drawString("Your accusation was incorrect. Game over. ", 1010,750); 
                won = false; 
                gameOver = true; 
			}
            playAgain.setVisible(true); 
		}

        if(gameOver==true && won==true){
           winningScreen(g); 
        }else if(gameOver ==true && won == false){
            losingScreen(g);
        }

        if(revealCards == true ){
            showCards.setVisible(false); 
            hideCards.setVisible(true); 
            g.setColor(Color.BLACK); 
            Font smallSerif = new Font("Serif", Font.PLAIN, 15);
            g.setFont(smallSerif);
            if(turn==1){
                String card1 = scarletCards.get(0); 
                String card2= scarletCards.get(1); 
                String card3 =scarletCards.get(2); 
                String card4 = scarletCards.get(3); 
                
                g.drawString("Ms. Scarlet has: ",1010,800);
                g.drawString(card1,1010,815); 
                g.drawString(card2,1010,830); 
                g.drawString(card3, 1010,845); 
                g.drawString(card4,1010,860); 
            }
            if(turn==2){
                String card1 = mustardCards.get(0); 
                String card2= mustardCards.get(1); 
                String card3 =mustardCards.get(2); 
                String card4 = mustardCards.get(3); 
                
                g.drawString("Colonel Mustard has: ",1010,800);
                g.drawString(card1,1010,815); 
                g.drawString(card2,1010,830); 
                g.drawString(card3, 1010,845); 
                g.drawString(card4,1010,860); 
            }
            if(turn==3){
                String card1 = plumCards.get(0); 
                String card2= plumCards.get(1); 
                String card3 =plumCards.get(2); 
                String card4 = plumCards.get(3); 
                
                g.drawString("Professor Plum has: ",1010,800);
                g.drawString(card1,1010,815); 
                g.drawString(card2,1010,830); 
                g.drawString(card3, 1010,845); 
                g.drawString(card4,1010,860); 
            }
            if(turn==4){
                String card1 = peacockCards.get(0); 
                String card2= peacockCards.get(1); 
                String card3 =peacockCards.get(2); 
                String card4 = peacockCards.get(3); 
                
                g.drawString("Mrs. Peacock has: ",1010,800);
                g.drawString(card1,1010,815); 
                g.drawString(card2,1010,830); 
                g.drawString(card3, 1010,845); 
                g.drawString(card4,1010,860); 
            }
        }else if(revealCards ==false && gameStart ==true){
            showCards.setVisible(true); 
            hideCards.setVisible(false);
        }

       repaint();


   }


   public void rulesScreen(Graphics g){
       g.setColor(Color.WHITE);
       g.fillRect(600, 300, 310, 310);
       g.setColor(Color.BLACK);
       Font font2 = new Font("Serif", Font.PLAIN, 12);
       g.setFont(font2);
       g.drawString("Rules", 750, 325);
       g.drawString("1. Use arrow keys to move.", 605, 345);
       g.drawString("1. To Enter rooms through doors, press the 'Enter Room' button.", 605, 365);
       g.drawString("2. At the start of each turn, players roll a dice to determine", 605, 385);
       g.drawString("the number of spaces they can move on the board", 615, 400);
       g.drawString("3. To suspect consists of naming a suspect, a weapon, and the", 605, 420);
       g.drawString("room that the player has moved into. Once a suspicion is", 615, 435);
       g.drawString("made, the game will reveal one named card in another", 615, 450);
       g.drawString("player's hand. When a card is shown, that suspicion is", 615, 465);
       g.drawString("to be false. If no one disproves the suspicion then the", 615, 480);
       g.drawString("the player may make an accusation.", 615, 495);
       g.drawString("4. When making an accusation, the player must state that they", 605, 515);
       g.drawString("are making an accusation then name the three cards they", 615, 530);
       g.drawString("believe to be in the crime scene. The player does not have", 615, 545);
       g.drawString("to be in the room they mention. If the accusation is right,", 615, 560);
       g.drawString("that player is the winner.", 615, 575);
       g.drawString("5. At the end of your turn, press the 'Next Turn' button.", 605, 595);
   }


   public void actionPerformed(ActionEvent e) {
   
      if(e.getSource() == playButton ){
           gameStart = true;
           remove(playButton);
      }
      if(e.getSource() == rulesButton){
           rules = true;
           remove(playButton);
          
      }


      if(e.getSource() == rollButton){
            if(rolled == 0){
                int roll = (int)(Math.random()*6+1);
                squaresToMove = roll;
                System.out.println("roll "  + roll);
                showRoll = true;
                rollButton.setVisible(false);
            }
            rolled = 1;
      }
      if(e.getSource() == exit){
           rules = false;
           this.add(playButton);
      }
     
      if(e.getSource() == suspectButton){
           animate = true;
           
           suspectedRoom = (String)roomList.getSelectedItem();
           suspectedWeapon = (String)weaponList.getSelectedItem();
           suspectedPerson = (String)characterList.getSelectedItem();
           enterRoomButton.setVisible(false);
           System.out.println("suspect");
         
           playSound("AmongUs_Sus.wav");
           suspect();
           
       }


       if(e.getSource()==enterRoomButton){
           inRoom = true;
           //System.out.println("enter room " + peacockX + ", " + peacockY);
           if(turn == 1){
               System.out.println(scarletX + ", " + scarletY);
               int c = scarletX/50;
               int r = scarletY/50;
              
               if(grid[r][c].equals("A")){
                   scarletY += 150;
                   door = "A";
               } else if(grid[r][c].equals("B")){
                   scarletX -= 100;
                   scarletY += 50;
                   door = "B";
               } else if(grid[r][c].equals("C")){
                   scarletY -= 100;
                   door = "C";
               } else if(grid[r][c].equals("D")){
                   scarletX += 100;
                   scarletY += 50;
                   door = "D";
               }
               System.out.println(scarletX);
           } else if(turn == 2){
               int c = mustardX/50;
               int r = mustardY/50;
               if(grid[r][c].equals("A")){
                   mustardY += 150;
                   door = "A";
               } else if(grid[r][c].equals("B")){
                   mustardX -= 100;
                   mustardY += 50;
                   door = "B";
               } else if(grid[r][c].equals("C")){
                   mustardY -= 100;
                   door = "C";
               } else if(grid[r][c].equals("D")){
                   mustardX += 100;
                   mustardY += 50;
                   door = "D";
               }
           } else if(turn == 3){
               int c = plumX/50;
               int r = plumY/50;
               if(grid[r][c].equals("A")){
                   plumY += 150;
                   door = "A";
               } else if(grid[r][c].equals("B")){
                   plumX -= 100;
                   plumY += 50;
                   door = "B";
               } else if(grid[r][c].equals("C")){
                   plumY -= 100;
                   door = "C";
               } else if(grid[r][c].equals("D")){
                   plumX += 100;
                   plumY += 50;
                   door = "D";
               }
           } else if(turn == 4){
               int c = peacockX/50;
               int r = peacockY/50;
               if(grid[r][c].equals("A")){
                   peacockY += 150;
                   door = "A";
               } else if(grid[r][c].equals("B")){
                   peacockX -= 100;
                   peacockY += 50;
                   door = "B";
               } else if(grid[r][c].equals("C")){
                   peacockY -= 100;
                   door = "C";
               } else if(grid[r][c].equals("D")){
                   peacockX += 100;
                   peacockY += 50;
                   door = "D";
               }
               //System.out.println(peacockY);
           }
              
          
       }


       if(e.getSource()==nextTurn){
            rolled = 0;
           showSuspection = false;
           inRoom = false; 
           showAccusation = false; 
           roomList.setVisible(false);
           characterList.setVisible(false);
           weaponList.setVisible(false);
           suspectButton.setVisible(false);
		   accuseButton.setVisible(false); 
           enterRoomButton.setVisible(false);

            inRoom = false;
            if(turn == 1){
               if(door.equals("A")){
                   scarletY -= 150;
                   door = "";
               } else if(door.equals("B")){
                   scarletX += 100;
                   scarletY -= 50;
                   door = "";
               } else if(door.equals("C")){
                   scarletY += 100;
                   door = "";
               } else if(door.equals("D")){
                   scarletX -= 100;
                   scarletY -= 50;
                   door = "";
               }
           } else if(turn == 2){
               if(door.equals("A")){
                   mustardY -= 150;
                   door = "";
               } else if(door.equals("B")){
                   mustardX += 100;
                   mustardY -= 50;
                   door = "";
               } else if(door.equals("C")){
                   mustardY += 100;
                   door = "";
               } else if(door.equals("D")){
                   mustardX -= 100;
                   mustardY -= 50;
                   door = "";
               }
           } else if(turn == 3){
               if(door.equals("A")){
                   plumY -= 150;
                   door = "";
               } else if(door.equals("B")){
                   plumX += 100;
                   plumY -= 50;
                   door = "";
               } else if(door.equals("C")){
                   plumY += 100;
                   door = "";
               } else if(door.equals("D")){
                   plumX -= 100;
                   plumY -= 50;
                   door = "";
               }
           } else if(turn == 4){
               if(door.equals("A")){
                   peacockY -= 150;
                   door = "";
               } else if(door.equals("B")){
                   peacockX += 100;
                   peacockY -= 50;
                   door = "";
               } else if(door.equals("C")){
                   peacockY += 100;
                   door = "";
               } else if(door.equals("D")){
                   peacockX -= 100;
                   peacockY -= 50;
                   door = "";
               }
           }
           
           turn++;
       }
	   
	   if(e.getSource()==accuseButton){
            restarting = false;
			accuse(); 
            playSound("AmongUs_Button.wav");
	   }

       if(e.getSource()==showCards){
            revealCards = true; 
       }
       if(e.getSource()==hideCards){
            revealCards = false; 
       }
       if(e.getSource() == playAgain){
            restarting = true; 
            restart();
            
       }
       repaint();
   }   

    public void restart(){
        for(int i = 0 ; i<scarletCards.size(); i++){
            scarletCards.remove(i); 
            i--;
        }
        for(int i = 0 ; i<mustardCards.size(); i++){
            mustardCards.remove(i); 
            i--;
        }
        for(int i = 0 ; i<plumCards.size(); i++){
            plumCards.remove(i); 
            i--;
        }
        for(int i = 0 ; i<peacockCards.size(); i++){
            peacockCards.remove(i); 
            i--;
        }


        cards.add("Person: Colonel Mustard");
       cards.add("Person: Mrs. Scarlet");
       cards.add("Person: Professor Plum");
       cards.add("Person: Mrs. Peacock");
       cards.add("Weapon: Wrench");
       cards.add("Weapon: Rope");
       cards.add("Weapon: Dagger");
       cards.add("Weapon: Candlestick");
       cards.add("Weapon: Revolver");
       cards.add("Weapon: Lead pipe");
       cards.add("Room: Ballroom");
       cards.add("Room: Conservatory");
       cards.add("Room: BillardRoom");
       cards.add("Room: Library");
       cards.add("Room: Study");
       cards.add("Room: Hall");
       cards.add("Room: Lounge");
       cards.add("Room: Dining Room");
       cards.add("Room: Kitchen");
                      
       shuffleCards();
      
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Room")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Person")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       for(int i = 0 ; i<cards.size(); i++){
           if(cards.get(i).indexOf("Weapon")>0){
               secretCards.add(cards.get(i));
               cards.remove(i);
               i=cards.size();
           }
       }
       
       scarletCards.add(cards.get(0));
       scarletCards.add(cards.get(1));
       scarletCards.add(cards.get(2));
       scarletCards.add(cards.get(3));

       mustardCards.add(cards.get(4));
       mustardCards.add(cards.get(5));
       mustardCards.add(cards.get(6));
       mustardCards.add(cards.get(7));

       peacockCards.add(cards.get(8));
       peacockCards.add(cards.get(9));
       peacockCards.add(cards.get(10));
       peacockCards.add(cards.get(11));

       plumCards.add(cards.get(12));
       plumCards.add(cards.get(13));
       plumCards.add(cards.get(14));
       plumCards.add(cards.get(15));


       for(int i =0; i<cards.size();i++){
           cards.remove(i);
           i--;
       }

        scarletX = 306;
        scarletY = 853;
        peacockX = 954;
        peacockY = 256;
        mustardX = 605;
        mustardY = 857;
        plumX = 956;
        plumY = 607;

        showSuspection = false;
        showAccusation = false; 
        inRoom = false;

        roomList.setVisible(false); 
        characterList.setVisible(false); 
        weaponList.setVisible(false);
        suspectButton.setVisible(false);
        accuseButton.setVisible(false);
    }
    
    public void playSound(String fileName) {

        try {
            URL url = this.getClass().getClassLoader().getResource(fileName);
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(url));
            clip.start();
        } catch (Exception exc) {
            exc.printStackTrace(System.out);
        }
    }

   public void suspect(){
	    accuseButton.setVisible(true); 
       showMe = "";
       System.out.println("Room " + suspectedRoom);
       System.out.println("Weapon " + suspectedWeapon);
       System.out.println("Person " + suspectedPerson);
       if(turn ==1){
           //mustards cards
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           //plums cards
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           //peacock cards
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
            for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
            }
			showMe = "None of those Cards were found";
			who = "";  
       }if(turn ==2){
           //plums cards
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           //peacock cards
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe +=suspectedRoom;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe +=suspectedWeapon;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe +=suspectedPerson;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           //scarlet cards
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe+= suspectedWeapon;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }  
		   showMe = "None of those Cards were found";
			who = "";
       }if(turn==3){
           //peacock cards
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<peacockCards.size();i++){
               if(peacockCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Mrs. Peacock";
                   showSuspection = true;
                   return;
               }
           }
           //scarlet cards
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }  
           //mustard cards
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
		   showMe = "None of those Cards were found";
			who = "";
       }if(turn==4){
           //scarlet cards
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<scarletCards.size();i++){
               if(scarletCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Ms. Scarlet";
                   showSuspection = true;
                   return;
               }
           }  
           //mustard cards
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<mustardCards.size();i++){
               if(mustardCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Colonel Mustard";
                   showSuspection = true;
                   return;
               }
           }
           //plums cards
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedRoom) >-1){
                   showMe += suspectedRoom;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedWeapon) >-1){
                   showMe += suspectedWeapon;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
           for(int i = 0; i<plumCards.size();i++){
               if(plumCards.get(i).indexOf(suspectedPerson) >-1){
                   showMe += suspectedPerson;
                   who = "Professor Plum";
                   showSuspection = true;
                   return;
               }
           }
		   showMe = "None of those Cards were found";
			who = "";
       }
      
   } 
   
   public void accuse(){
		for(int i = 0 ; i<secretCards.size(); i++){
			if(secretCards.get(i).indexOf(suspectedRoom)>-1){
				correctness++; 
			}
			if(secretCards.get(i).indexOf(suspectedWeapon)>-1){
				correctness++; 
			}
			if(secretCards.get(i).indexOf(suspectedPerson)>-1){
				correctness++; 
			}
		}
		showAccusation=true; 
   }
  
   public void shuffleCards(){
       for(int i = 0 ; i<cards.size(); i++){
           int random = (int)(Math.random()*cards.size());
           String temp = cards.get(random);
           cards.set(random, cards.get(i));
           cards.set(i, temp);
       }
   }
  
  
   public boolean haveAccess(int x, int y){
       int row = y/50;
       int col = x/50;
       if(grid[row][col].equals("0") || grid[row][col].equals("A") || grid[row][col].equals("B") || grid[row][col].equals("C") || grid[row][col].equals("D")){
           return true;
       }else{
           return false;
       }
   }


    public void animate(){
        while(true){
          
           if(animate == true){
               imgX++;
               System.out.println("animate");
           }
           try {
               Thread.sleep(2);
           } catch (InterruptedException ex) {
               Thread.currentThread().interrupt();
           }




           if(imgX > 1450){
               imgX = -575;
               animate = false;
           }
          
           repaint();
        }
    }

    public void losingScreen(Graphics g){
        if(restarting == false){
            g.setColor(Color.BLACK);
            g.fillRect(650, 450, 220, 100);
            g.setColor(Color.WHITE);
            g.fillRect(660, 460, 200, 80);
            g.setColor(Color.BLACK);
            Font font = new Font("Serif", Font.PLAIN, 30);
            g.setFont(font);
            g.drawString("You Lost", 700, 500);
        }
    }

    public void winningScreen(Graphics g){
        if(restarting == false){
            g.setColor(Color.BLACK);
            g.fillRect(650, 450, 220, 100);
            g.setColor(Color.WHITE);
            g.fillRect(660, 460, 200, 80);
            g.setColor(Color.BLACK);
            Font font = new Font("Serif", Font.PLAIN, 30);
            g.setFont(font);
            g.drawString("You Won", 700, 500);
        }
    }

//mouse listener
   public void mousePressed(MouseEvent e) {
       System.out.println(e.getX()+","+e.getY());
   }
   public void mouseReleased(MouseEvent e) {}
   public void mouseEntered(MouseEvent e) {}
   public void mouseExited(MouseEvent e) {}
   public void mouseClicked(MouseEvent e) {}
  
//keyboard listener
   public void keyPressed(KeyEvent e){
       //System.out.println(e.getKeyCode());
      
       if(squaresToMove > 0){
          
           if(e.getKeyCode() == 38){ //up arrow
               //move the player up
               if(turn == 1){
                   int nextY = scarletY-50;
                   int nextX = scarletX;
                   if(haveAccess(nextX, nextY) ==true ){
                       scarletX = nextX;
                       scarletY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 2){
                   int nextY = mustardY-50;
                   int nextX = mustardX;
                   if(haveAccess(nextX, nextY) ==true ){
                       mustardX = nextX;
                       mustardY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 3){
                   int nextY = plumY-50;
                   int nextX = plumX;
                   if(haveAccess(nextX, nextY) ==true ){
                       plumX = nextX;
                       plumY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 4){
                   int nextY = peacockY-50;
                   int nextX = peacockX;
                   if(haveAccess(nextX, nextY) ==true ){
                       peacockX = nextX;
                       peacockY = nextY;
                       squaresToMove--;
                   }
               }
           } else if(e.getKeyCode() == 40){ //down arrow
               //move the player down
               if(turn == 1){
                   scarletY += 50;
               } else if(turn == 2){
                   int nextY = mustardY + 50;
                   int nextX = mustardX;
                   if(haveAccess(nextX, nextY) ==true ){
                       mustardX = nextX;
                       mustardY = nextY;
                       squaresToMove--;
                   }
               } else if(turn == 3){
                   int nextY = plumY+50;
                   int nextX = plumX;
                   if(haveAccess(nextX, nextY) ==true ){
                       plumX = nextX;
                       plumY = nextY;
                       squaresToMove--;
                   }
               } else if(turn == 4){
                   int nextY = peacockY+50;
                   int nextX = peacockX;
                   if(haveAccess(nextX, nextY) ==true ){
                       peacockX = nextX;
                       peacockY = nextY;
                       squaresToMove--;
                   }
               }
           } else if (e.getKeyCode()==39){//right
               if(turn == 1){
                   int nextY = scarletY;
                   int nextX = scarletX + 50;
                   if(haveAccess(nextX, nextY) ==true ){
                       scarletX = nextX;
                       scarletY = nextY;
                       squaresToMove--;
                   }
               } else if(turn == 2){
                   int nextY = mustardY;
                   int nextX = mustardX + 50;
                   if(haveAccess(nextX, nextY) ==true ){
                       mustardX = nextX;
                       mustardY = nextY;
                       squaresToMove--;
                   }
               } else if(turn == 3){
                   int nextY = plumY;
                   int nextX = plumX+50;
                   if(haveAccess(nextX, nextY) ==true ){
                       plumX = nextX;
                       plumY = nextY;
                       squaresToMove--;
                   }
               } else if(turn == 4){
                   int nextY = peacockY;
                   int nextX = peacockX+50;
                   if(haveAccess(nextX, nextY) ==true ){
                       peacockX = nextX;
                       peacockY = nextY;
                       squaresToMove--;
                   }
               }
           } else if (e.getKeyCode() == 37){//left
               if(turn == 1){
                   int nextY = scarletY;
                   int nextX = scarletX - 50;
                   if(haveAccess(nextX, nextY) ==true ){
                       scarletX = nextX;
                       scarletY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 2){
                   int nextY = mustardY;
                   int nextX = mustardX-50;
                   if(haveAccess(nextX, nextY) ==true ){
                       mustardX = nextX;
                       mustardY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 3){
                   int nextY = plumY;
                   int nextX = plumX-50;
                   if(haveAccess(nextX, nextY) ==true ){
                       plumX = nextX;
                       plumY = nextY;
                       squaresToMove--;
                   }
               }else if(turn == 4){
                   int nextY = peacockY;
                   int nextX = peacockX-50;
                   if(haveAccess(nextX, nextY) ==true ){
                       peacockX = nextX;
                       peacockY = nextY;
                       squaresToMove--;
                   }
               }
           }
          
           repaint();
       }
      
      
   }
   public void keyReleased(KeyEvent e){}
   public void keyTyped(KeyEvent e){}
}